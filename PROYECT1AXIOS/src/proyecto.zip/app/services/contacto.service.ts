import { Injectable } from '@angular/core';
import axios, { AxiosInstance, AxiosError } from 'axios';

// URL base de la API en PHP. Todo lo que se pida después (ej. crearContacto)
// se concatena a partir de esta URL.
const API_URL = 'http://localhost/api';

// INTERFACE = el "molde"/modelo de datos. Describe qué forma tiene un Contacto,
// sin ninguna lógica, solo la estructura.
// Los campos con "?" son OPCIONALES:
// - id, created_at, updated_at no existen todavía cuando CREAS un contacto nuevo
//   (los genera el servidor), pero sí vienen cuando el servidor te lo REGRESA.
export interface Contacto {
  id?: number;
  nombre: string;
  empresa?: string;
  email: string;
  telefono: string;
  mensaje: string;
  created_at?: string;
  updated_at?: string;
}

// Molde genérico para TODAS las respuestas de la API — siempre regresan
// success (true/false), un mensaje, y los datos (el tipo T cambia según el caso).
export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data: T;
}

// @Injectable + providedIn:'root' = convierte esta clase en un SERVICIO de Angular.
// "providedIn: root" significa que hay UNA sola instancia de este servicio
// compartida por TODA la app (no se crea una copia nueva por cada componente que lo use).
@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  // Instancia de Axios ya configurada, privada (solo se usa dentro de esta clase)
  private http: AxiosInstance;

  constructor() {
    // axios.create() arma un "cliente HTTP" preconfigurado, para no repetir
    // la URL base y las cabeceras en cada llamada.
    this.http = axios.create({
      baseURL: API_URL,
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 10000 // si el servidor no responde en 10 segundos, se considera error
    });
  }

  // Método privado de ayuda: convierte cualquier error de Axios en un mensaje
  // de texto legible para mostrarlo en el modal de error.
  private extraerMensajeError(error: AxiosError<ApiResponse>): string {
    // Caso 1: el servidor SÍ respondió, pero con un error (ej. validación fallida)
    if (error.response?.data?.message) {
      return error.response.data.message;
    }
    // Caso 2: la petición se mandó, pero nunca llegó respuesta (servidor caído, CORS, sin internet)
    if (error.request) {
      return 'No se pudo conectar con el servidor. Verifica tu conexión.';
    }
    // Caso 3: algo salió mal antes de siquiera mandar la petición
    return 'Ocurrió un error inesperado.';
  }

  // ---------- CRUD ----------
  // Cada método sigue el mismo patrón: intenta la petición con axios,
  // si truena, usa extraerMensajeError() y relanza el error ya "traducido".

  // READ (listar todos) → GET /index.php
  async obtenerContactos(): Promise<Contacto[]> {
    try {
      const { data } = await this.http.get<ApiResponse<Contacto[]>>('/index.php');
      return data.data; // el "data.data" es porque ApiResponse envuelve el arreglo real adentro de "data"
    } catch (error) {
      throw new Error(this.extraerMensajeError(error as AxiosError<ApiResponse>));
    }
  }

  // READ (uno solo) → GET /index.php?id=X
  async obtenerContacto(id: number): Promise<Contacto> {
    try {
      const { data } = await this.http.get<ApiResponse<Contacto>>(`/index.php?id=${id}`);
      return data.data;
    } catch (error) {
      throw new Error(this.extraerMensajeError(error as AxiosError<ApiResponse>));
    }
  }

  // CREATE → POST /index.php (los datos van en el "body" de la petición)
  async crearContacto(contacto: Contacto): Promise<Contacto> {
    try {
      const { data } = await this.http.post<ApiResponse<Contacto>>('/index.php', contacto);
      return data.data;
    } catch (error) {
      throw new Error(this.extraerMensajeError(error as AxiosError<ApiResponse>));
    }
  }

  // UPDATE completo → PUT /index.php?id=X (reemplaza TODOS los campos)
  async actualizarContacto(id: number, contacto: Contacto): Promise<Contacto> {
    try {
      const { data } = await this.http.put<ApiResponse<Contacto>>(`/index.php?id=${id}`, contacto);
      return data.data;
    } catch (error) {
      throw new Error(this.extraerMensajeError(error as AxiosError<ApiResponse>));
    }
  }

  // UPDATE parcial → PATCH /index.php?id=X (solo cambia los campos que mandes)
  // Partial<Contacto> significa "un Contacto, pero con todos sus campos opcionales"
  async actualizarContactoParcial(id: number, cambios: Partial<Contacto>): Promise<Contacto> {
    try {
      const { data } = await this.http.patch<ApiResponse<Contacto>>(`/index.php?id=${id}`, cambios);
      return data.data;
    } catch (error) {
      throw new Error(this.extraerMensajeError(error as AxiosError<ApiResponse>));
    }
  }

  // DELETE → borra el contacto con ese id
  async eliminarContacto(id: number): Promise<void> {
    try {
      await this.http.delete<ApiResponse<null>>(`/index.php?id=${id}`);
    } catch (error) {
      throw new Error(this.extraerMensajeError(error as AxiosError<ApiResponse>));
    }
  }
}