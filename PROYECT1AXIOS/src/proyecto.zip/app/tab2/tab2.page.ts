import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonSpinner, IonRefresher, IonRefresherContent, IonIcon
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import { mailOutline, callOutline, businessOutline, timeOutline } from 'ionicons/icons';
import { ContactoService, Contacto } from '../services/contacto.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonSpinner, IonRefresher, IonRefresherContent, IonIcon
  ],
})
export class Tab2Page implements OnInit {

  contactos: Contacto[] = [];
  cargando = true;
  error = '';

  constructor(
    private contactoService: ContactoService,
    private cdr: ChangeDetectorRef
  ) {
    addIcons({
      'mail-outline': mailOutline,
      'call-outline': callOutline,
      'business-outline': businessOutline,
      'time-outline': timeOutline
    });
  }

  ngOnInit() {
    this.cargarContactos();
  }

  async cargarContactos(event?: any) {
    this.error = '';
    this.cargando = true;
    try {
      this.contactos = await this.contactoService.obtenerContactos();
    } catch (err: any) {
      this.error = err?.message || 'No se pudieron cargar los contactos.';
    } finally {
      this.cargando = false;
      this.cdr.detectChanges();
      if (event) {
        event.target.complete();
      }
    }
  }

  // Iniciales para el círculo de avatar, ej. "Juan Pérez" -> "JP"
  iniciales(nombre: string): string {
    return nombre
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map(p => p[0].toUpperCase())
      .join('');
  }
}